package com.apuestasdeportivas;





import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.utils.UtilsViews;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.*;

public class newuser {

    
    @FXML
    private Button crearButton;

    @FXML
    private Button backButton;
    @FXML
    private TextField nom;
    @FXML
    private TextField cognom;
    @FXML
    private TextField correu;
    @FXML
    private TextField usuari1;
    @FXML
    private PasswordField password;
    @FXML
    private PasswordField ConfirmarPassword;

    @FXML
    private TextField dni;
    


    
    @FXML
    private void Enrere(ActionEvent event) throws Exception {
        //MainController crtl = (MainController) UtilsViews.getController("ViewMain");

        //crtl.loadView("/assets/vistaPrincipal.fxml");
        UtilsViews.setViewAnimating("ViewMain");
        //try {
            // Cargar la nueva vista desde el archivo FXML
          //  URL resource = this.getClass().getResource("/assets/vistaPrincipal.fxml");
            

            //FXMLLoader loader = new FXMLLoader(resource);
            //Parent itemPane = loader.load();
            
            //UtilsViews.setView("ViewDetalls"); 
            
            //Scene scene = new Scene(itemPane);
            //Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            //stage.setScene(scene);
            
        //} catch (IOException e2) {
           // e2.printStackTrace(); 

        //}
    }






    @FXML
    private void crearUsuari(){

        String passwd = "";

        String nomChoiceBox = nom.getText();
        String cognomChoice = cognom.getText();
        String usuariText = usuari1.getText();
        String dniText = dni.getText();
        System.out.println(nomChoiceBox);
        System.out.println(cognomChoice);

        String mail = correu.getText();
        if (password.getText().equals(ConfirmarPassword.getText())){
            passwd = password.getText();

        }
        usuaris usuariNou = new usuaris(nomChoiceBox, cognomChoice, dniText, usuariText,passwd,mail,0.0);
        UsuariDao usuariDao = new UsuariDao();
        usuariDao.add(usuariNou);
        System.out.println("usuari creat");
        UtilsViews.setViewAnimating("ViewLogin");


    }


    

   
}