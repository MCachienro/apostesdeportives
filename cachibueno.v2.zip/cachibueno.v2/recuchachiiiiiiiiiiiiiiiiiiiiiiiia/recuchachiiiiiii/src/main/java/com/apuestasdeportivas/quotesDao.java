package com.apuestasdeportivas;

public class quotesDao {
    public void afegirQuota(quotes quota) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "INSERT INTO quotes(partit_id, descripcio, quota, equip_id) VALUES (" + 
                     quota.getPartit_id() + ", '" + quota.getDescripcio() + "', " + quota.getQuota() + ", " + quota.getequip_id() + ")";
    
        db.update(sql);
    }
    
    public void editarQuota(int id, quotes quota) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "UPDATE quotes SET " +
                     "partit_id = " + quota.getPartit_id() + ", " +
                     "descripcio = '" + quota.getDescripcio() + "', " +
                     "quota = " + quota.getQuota() + " " +
                     "equip_id = " + quota.getequip_id() + " " +
                     "WHERE id = " + id;
    
        db.update(sql);
    }
    
    public void eliminarQuota(int id) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "DELETE FROM quotes WHERE id = " + id;
    
        db.update(sql);
    }
}
