package com.apuestasdeportivas;

public class db {

    public static void insertarUsers(){
        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
 
        String deleteClientsSql = "DELETE FROM usuari";
        db.update(deleteClientsSql);
    
        String sql = """
            INSERT INTO usuari (nom, cognoms, usuaris, contrasenya, dni, email, saldo)
            VALUES 
            ('Albert', 'Palacios', 'a','a', '12345678A', 'apalacios@xtec.cat', 20.00);
        """;
    
        db.update(sql);
    }
    public static void insertarDatosEjemplo() {
        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
    
        // Limpiar datos antiguos
        db.update("DELETE FROM aposta");
        db.update("DELETE FROM quotes");
        db.update("DELETE FROM partit");
        db.update("DELETE FROM equip");
        db.update("DELETE FROM esports");
        db.update("DELETE FROM usuari");
    
        // Insertar usuarios
        db.update("""
            INSERT INTO usuari (nom, cognoms, usuaris, contrasenya, dni, email, saldo) VALUES
            ('Albert', 'Palacios', 'a','a', '12345678A', 'apalacios@xtec.cat', 20.00),
            ('Maria', 'Lopez', 'm','m', '87654321B', 'mlopez@xtec.cat', 50.00);
        """);
    
        // Insertar esports
        db.update("""
            INSERT INTO esports (nom) VALUES
            ('Futbol'),
            ('Bàsquet');
        """);
    
        // Insertar equips
        db.update("""
            INSERT INTO equip (nom,imatge,esports_id) VALUES
            ('FC Barcelona','/assets/images/barca.jpg',1),
            ('Real Madrid','/assets/images/madrid.png',1),
            ('Chicago Bulls','/assets/images/bulls.png',2),
            ('LA Lakers','/assets/images/lakers.png',2);
        """);
    
        // Insertar partits (deben coincidir ids)
        db.update("""
            INSERT INTO partit (id_local, id_visitant, data, esport_id) VALUES
            (1,2, '2025-06-10', 1),
            (3,4, '2025-06-11', 2);
        """);
    
        // Insertar quotes
        db.update("""
            INSERT INTO quotes (partit_id, descripcio, quota, equip_id) VALUES
            (1, 'Guanya FC Barcelona', 1.80, 1),
            (1, 'Guanya Real Madrid', 2.10, 2),
            (2, 'Guanya Bulls', 1.95, 3),
            (2, 'Guanya Lakers', 2.00, 4);
        """);
    
        // Insertar apuestes
        db.update("""
            INSERT INTO aposta (usuari_id, quota_id, import) VALUES
            ('12345678A', 1, 10.00),
            ('87654321B', 3, 15.00);
        """);
    }
    
    public static void crearusuaris() {


        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
        db.update("DROP TABLE IF EXISTS usuari");
        
        db.update("""
                CREATE TABLE IF NOT EXISTS usuari(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom VARCHAR(255) NOT NULL,
                cognoms VARCHAR(255) NOT NULL,
                usuaris VARCHAR(255) NOT NULL,
                contrasenya VARCHAR(255) NOT NULL,
                dni VARCHAR(9) NOT NULL UNIQUE,
                email VARCHAR(100) NOT NULL,
                saldo DECIMAL(10,2) DEFAULT 0
                )
                """);
    }

    public static void crearesports() {
        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
        db.update("DROP TABLE IF EXISTS esports");
        
        db.update("""
                CREATE TABLE IF NOT EXISTS esports(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom VARCHAR(255) NOT NULL
                )
                """);
    }

    public static void crearpartits() {
        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
        db.update("DROP TABLE IF EXISTS partit");
    
        db.update("""
            CREATE TABLE IF NOT EXISTS partit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_local INTEGER NOT NULL,
                id_visitant INTEGER NOT NULL,
                data DATE NOT NULL,
                esport_id INTEGER NOT NULL,
                FOREIGN KEY (esport_id) REFERENCES esports(id),
                FOREIGN KEY (id_local) REFERENCES equip(id),
                FOREIGN KEY (id_visitant) REFERENCES equip(id)
            )
        """);
    }
    

    public static void crearequip() {
        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
        db.update("DROP TABLE IF EXISTS equip");
        
        db.update("""
                CREATE TABLE IF NOT EXISTS equip(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom VARCHAR(255) NOT NULL,
                imatge TEXT,
                esports_id INTEGER,
                FOREIGN KEY (esports_id) REFERENCES esports(id)
                )
                """);
    }
    public static void crearquotes() {
        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
        db.update("DROP TABLE IF EXISTS quotes");
    
        db.update("""
                CREATE TABLE IF NOT EXISTS quotes(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                partit_id INTEGER NOT NULL,
                descripcio TEXT NOT NULL,  
                quota DECIMAL(10,2) NOT NULL,  
                equip_id INTEGER NOT NULL,       
                FOREIGN KEY (partit_id) REFERENCES partit(id)
                FOREIGN KEY (equip_id) REFERENCES equip(id)
                )
                """);
    }
    
    

    public static void crearaposta() {
        AppData db = AppData.getInstance();
        db.connect("data/apuestas.sqlite");
        db.update("DROP TABLE IF EXISTS aposta");
        
        db.update("""
                CREATE TABLE IF NOT EXISTS aposta(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuari_id INTEGER NOT NULL,
                quota_id INTEGER NOT NULL,
                import DECIMAL(10,2) NOT NULL,             
                data TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuari_id) REFERENCES usuari(dni),
                FOREIGN KEY (quota_id) REFERENCES quotes(id)
                )
                """);
    }

    



}