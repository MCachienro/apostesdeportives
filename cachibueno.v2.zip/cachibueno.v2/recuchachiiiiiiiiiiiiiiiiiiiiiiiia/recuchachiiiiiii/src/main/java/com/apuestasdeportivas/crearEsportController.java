package com.apuestasdeportivas;

import com.utils.UtilsViews;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class crearEsportController {

    @FXML private Button buttonAdd;
    @FXML private Button backButton;
    @FXML private TextField nom;

    @FXML
    private void initialize() {
        // No es necesario cargar datos al inicio en este caso
    }

    @FXML
    private void Enrere(ActionEvent event) throws Exception {
        UtilsViews.setViewAnimating("ViewTabla");
    }

    @FXML
    private void CrearEsportNou() {
        String nomEsport = nom.getText();

        if (nomEsport == null || nomEsport.trim().isEmpty()) {
            mostrarAlerta("El nom de l'esport no pot estar buit.");
            return;
        }

        esport nouEsport = new esport();
        nouEsport.setNom(nomEsport);

        esportDao dao = new esportDao();
        dao.afegirEsport(nouEsport);

        mostrarAlertaInfo("Esport afegit correctament.");
        nom.clear(); // Limpiar el campo tras añadir
    }

    private void mostrarAlerta(String missatge) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(missatge);
        alert.show();
    }

    private void mostrarAlertaInfo(String missatge) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informació");
        alert.setHeaderText(null);
        alert.setContentText(missatge);
        alert.show();
    }
}
