package com.apuestasdeportivas;

public class Sessio {
    // The private static instance of the class
    private static Sessio instance;

    // The username variable that stores the logged-in user
    private String username;

    // Private constructor to prevent instantiation from outside
    private Sessio() {
    }

    public static Sessio getInstance() {
        if (instance == null) {
            System.out.println("Creating new instance of Sessio...");
            instance = new Sessio();
        } else {
            System.out.println("Using existing instance of Sessio...");
        }
        return instance;
    }
    

    // Getter and setter for the username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
