package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;

public class equipDao {

    // Agregar un equipo
    public void afegirEquip(equip equip) {
        AppData db = AppData.getInstance();

        // Obtener el ID del deporte a partir del nombre
        int deportesId = obtenerDeportesId(equip.getDeporte());

        if (deportesId == -1) {
            System.out.println("No se encontró el deporte: " + equip.getDeporte());
            return;
        }

        String sql = "INSERT INTO equip (nom, imatge, esports_id) VALUES ('"
                + equip.getNom().replace("'", "''") + "', '"
                + equip.getImatge().replace("'", "''") + "', "
                + deportesId + ")";

        try {
            db.update(sql);  // Usando la actualización de AppData para ejecutar la consulta
            System.out.println("Equip afegit correctament.");
        } catch (Exception e) {
            // Si hay error, hacemos rollback
            try {
                db.update("ROLLBACK;"); // Realizamos un rollback en caso de error
            } catch (Exception ex) {
                System.out.println("Error al realizar rollback: " + ex.getMessage());
            }
            System.out.println("Error en afegir l'equip: " + e.getMessage());
        }
    }

    // Actualizar equipo por ID
    public void update(int id, equip equip) {
        AppData db = AppData.getInstance();

        // Obtener el ID del deporte a partir del nombre
        int deportesId = obtenerDeportesId(equip.getDeporte());

        if (deportesId == -1) {
            System.out.println("No se encontró el deporte: " + equip.getDeporte());
            return;
        }

        String sql = "UPDATE equip SET "
                + "nom = '" + equip.getNom().replace("'", "''") + "', "
                + "imatge = '" + equip.getImatge().replace("'", "''") + "', "
                + "esports_id = " + deportesId + " "
                + "WHERE id = " + id;

        try {
            db.update(sql);  // Usamos la actualización de AppData
            System.out.println("Equip actualitzat correctament.");
        } catch (Exception e) {
            System.out.println("Error en actualitzar l'equip: " + e.getMessage());
        }
    }

    // Eliminar un equipo por ID
    public void eliminarEquip(int id) {
        AppData db = AppData.getInstance();

        String sql = "DELETE FROM equip WHERE id = " + id;

        try {
            db.update(sql);  // Usamos la actualización de AppData
            System.out.println("Equip eliminat correctament.");
        } catch (Exception e) {
            System.out.println("Error en eliminar l'equip: " + e.getMessage());
        }
    }

    // Obtener el ID de un deporte a partir de su nombre
    private int obtenerDeportesId(String nombreDeporte) {
        AppData db = AppData.getInstance();

        String sql = "SELECT id FROM esports WHERE nom = '" + nombreDeporte.replace("'", "''") + "'";
        ArrayList<HashMap<String, Object>> result = db.query(sql);

        if (result != null && !result.isEmpty()) {
            Object idValue = result.get(0).get("id");

            if (idValue instanceof Integer) return (Integer) idValue;
            else if (idValue instanceof Long) return ((Long) idValue).intValue();
        }

        return -1; // No encontrado
    }
}
