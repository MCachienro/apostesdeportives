package com.apuestasdeportivas;

public class partit {
    private int local_id;
    private int visitant_id;
    private String data;
    private int esport_id;
    private int id;

    public partit(int local_id, int visitant_id, String data, int esport_id) {
        this.local_id = local_id;
        this.visitant_id = visitant_id;
        this.data = data;
        this.esport_id = esport_id;
    }

    public int getLocal_id() {
        return this.local_id;
    }

    public void setLocal_id(int local_id) {
        this.local_id = local_id;
    }

    public int getVisitant_id() {
        return this.visitant_id;
    }

    public void setVisitant_id(int visitant_id) {
        this.visitant_id = visitant_id;
    }

    public String getData() {
        return this.data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getEsport_id() {
        return this.esport_id;
    }

    public void setEsport_id(int esport_id) {
        this.esport_id = esport_id;
    }

    public int getid(){
        return this.id;
    }
}
