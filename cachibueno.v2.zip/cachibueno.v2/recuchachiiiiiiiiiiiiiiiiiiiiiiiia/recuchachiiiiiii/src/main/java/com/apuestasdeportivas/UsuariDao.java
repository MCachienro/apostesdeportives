package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;

public class UsuariDao {

    public String getUserDNI(String nom, String cognom) {
        AppData db = AppData.getInstance();

        String sql = "SELECT dni FROM usuari WHERE nom = '" + nom + "' AND cognom = '" + cognom + "'";
        ArrayList<HashMap<String, Object>> resultat = db.query(sql);
        String dni = (String) resultat.get(0).get("dni");
        return dni;
    }

    public void add(usuaris usuari) {
        AppData db = AppData.getInstance();
    
        // Construir la consulta SQL amb els camps nous
        String sql = "INSERT INTO usuari (nom, cognoms, usuaris, contrasenya, dni, email, saldo) VALUES ('" 
                    + usuari.getNom() + "', '" 
                    + usuari.getCognom() + "', '" 
                    + usuari.getUsuari() + "', '" 
                    + usuari.getContrasenya() + "', '" 
                    + usuari.getDni() + "', '" 
                    + usuari.getEmail() + "', "
                    + usuari.getSaldo() + ")";
        
        db.update(sql);
    }
    
    public void update(int id, usuaris usuari) {
        AppData db = AppData.getInstance();
    
        // Verificació bàsica
        if (usuari.getNom() == null || usuari.getNom().isEmpty()) {
            System.out.println("El nom no pot estar buit");
            return;
        }
    
        // Consulta d'actualització amb els nous camps
        String sql = "UPDATE usuari SET "
                    + "nom = '" + usuari.getNom() + "', "
                    + "cognoms = '" + usuari.getCognom() + "', "
                    + "usuaris = '" + usuari.getUsuari() + "', "
                    + "contrasenya = '" + usuari.getContrasenya() + "', "
                    + "dni = '" + usuari.getDni() + "', "
                    + "email = '" + usuari.getEmail() + "', "
                    + "saldo = " + usuari.getSaldo() + " "
                    + "WHERE id = " + id;
    
        try {
            db.update(sql);
            System.out.println("Usuari actualitzat correctament");
        } catch (Exception e) {
            System.out.println("Error en actualitzar l’usuari: " + e.getMessage());
        }
    }

    public void delete(int id){
        AppData db = AppData.getInstance();

        String sql = "DELETE FROM usuari WHERE id = " + id;
        db.update(sql);
    }
}
