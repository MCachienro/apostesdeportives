package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;

public class esportDao {

    // Agregar un esport
    public void afegirEsport(esport esport) {
        AppData db = AppData.getInstance();

        String sql = "INSERT INTO esports (nom) VALUES ('"
                + esport.getNom().replace("'", "''") + "')";

        try {
            db.update(sql);
            System.out.println("Esport afegit correctament.");
        } catch (Exception e) {
            System.out.println("Error en afegir l'esport: " + e.getMessage());
        }
    }

    // Actualizar esport por ID
    public void update(int id, esport esport) {
        AppData db = AppData.getInstance();

        String sql = "UPDATE esports SET nom = '"
                + esport.getNom().replace("'", "''") + "' WHERE id = " + id;

        try {
            db.update(sql);
            System.out.println("Esport actualitzat correctament.");
        } catch (Exception e) {
            System.out.println("Error en actualitzar l'esport: " + e.getMessage());
        }
    }

    // Eliminar esport por ID
    public void eliminarEsport(int id) {
        AppData db = AppData.getInstance();

        String sql = "DELETE FROM esports WHERE id = " + id;

        try {
            db.update(sql);
            System.out.println("Esport eliminat correctament.");
        } catch (Exception e) {
            System.out.println("Error en eliminar l'esport: " + e.getMessage());
        }
    }

    // Obtener todos los esports
    public ArrayList<esport> obtenirTotsEsports() {
        AppData db = AppData.getInstance();
        String sql = "SELECT * FROM esports";
        ArrayList<HashMap<String, Object>> result = db.query(sql);

        ArrayList<esport> esports = new ArrayList<>();

        for (HashMap<String, Object> row : result) {
            esport e = new esport();
            e.setNom((String) row.get("nom"));
            esports.add(e);
        }

        return esports;
    }
}
