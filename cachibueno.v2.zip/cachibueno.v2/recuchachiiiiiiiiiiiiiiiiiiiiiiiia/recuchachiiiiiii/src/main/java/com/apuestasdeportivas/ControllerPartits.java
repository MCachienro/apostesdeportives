package com.apuestasdeportivas;


import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


import com.utils.UtilsViews;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class ControllerPartits {


    private int mangaId;

    @FXML
    private Button buttonAdd;
    @FXML
    private TextField quota,local,visitant;
    @FXML
    private ImageView img1,img2;
    @FXML
    private Button apostar;

    @FXML
    private void goToMainView(ActionEvent event) throws Exception {
        UtilsViews.setView("ViewTabla");  // Cambiar a la vista principal
    }
    
    @FXML

    //TODO
    
    private void Enrere(ActionEvent event) throws Exception {
        // Cargar la vista anterior usando FXMLLoader
        UtilsViews.setView("ViewTabla");
    }

    
@FXML
private void abrirEditor(ActionEvent event) {



}

    @FXML
    public void eliminar(ActionEvent e) throws Exception {
        //MangaDao mangaDao = new MangaDao();
        //mangaDao.delete(mangaId);
        UtilsViews.setView("ViewMain");
    }


    public void carregarView(int id) throws Exception {
        cargarManga(id);
        UtilsViews.setView("ViewPartit");

    }

    public void initialize(){
    }

    public void cargarManga(int idManga) {
        this.mangaId = idManga;
    
        String sql = "SELECT " +
            "    el.imatge AS imagen1, " +
            "    ev.imatge AS imagen2, " +
            "    q.quota, " +
            "    el.nom AS equipo_local, " +   // Agregar el nombre del equipo local
            "    ev.nom AS equipo_visitante " + // Agregar el nombre del equipo visitante
            "FROM quotes q " +
            "JOIN partit p ON q.partit_id = p.id " +
            "JOIN equip el ON p.id_local = el.id " +
            "JOIN equip ev ON p.id_visitant = ev.id " +
            "WHERE p.id = " + idManga;
        
        ArrayList<HashMap<String, Object>> mangaData = ObtenirManga(sql);
        System.out.println("datos del manga" + mangaData);
    
        if (!mangaData.isEmpty()) {
            PoblarCamps(mangaData);
        } else {
            System.out.println("No se encontraron datos para el manga con ID: " + idManga);
        }
    }
    
    public ArrayList<HashMap<String, Object>> ObtenirManga(String sql){
        AppData db = AppData.getInstance();

        ArrayList<HashMap<String, Object>> result = db.query(sql);
        
        // Verificar los resultados de la consulta
        System.out.println("Resultado de la consulta: " + result);
        return result;
    }

    public void PoblarCamps(ArrayList<HashMap<String, Object>> query) {
        System.out.println("PoblarCamps ejecutado");
    
        if (query != null && !query.isEmpty()) {
            HashMap<String, Object> map = query.get(0);
    
            // Verifica las claves
            for (String key : map.keySet()) {
                System.out.println("Clave encontrada: " + key);
            }
    
            // Obtener las rutas de las imágenes
            Object quotaValue = map.get("quota");
            String rawPath1 = (String) map.get("imagen1");
            String rawPath2 = (String) map.get("imagen2");
    
            // Obtener los nombres de los equipos
            String equipoLocal = (String) map.get("equipo_local");
            String equipoVisitante = (String) map.get("equipo_visitante");
    
            // Asegurarse de que la ruta comience con "/" y no esté vacía
            String imagePath1 = rawPath1.startsWith("/") ? rawPath1 : "/" + rawPath1;
            String imagePath2 = rawPath2.startsWith("/") ? rawPath2 : "/" + rawPath2;
    
            URL imageUrl1 = getClass().getResource(imagePath1);
            if (imageUrl1 != null) {
                Image image1 = new Image(imageUrl1.toExternalForm());
                img1.setImage(image1);
            } else {
                System.out.println("Error: imagen1 no encontrada: " + imagePath1);
            }
    
            URL imageUrl2 = getClass().getResource(imagePath2);
            if (imageUrl2 != null) {
                Image image2 = new Image(imageUrl2.toExternalForm());
                img2.setImage(image2);
            } else {
                System.out.println("Error: imagen2 no encontrada: " + imagePath2);
            }
    
            // Mostrar cuota
            if (quota != null && quotaValue != null) {
                quota.setText(quotaValue.toString());
            } else {
                System.out.println("? Error al cargar detalles: cuota es null o no existe el valor en el map.");
            }
            local.setText(equipoLocal);
            visitant.setText(equipoVisitante);
            // Mostrar los nombres de los equipos
            System.out.println("Equipo Local: " + equipoLocal);
            System.out.println("Equipo Visitante: " + equipoVisitante);
    
            // Aquí puedes, por ejemplo, mostrar los nombres de los equipos en algún control de la UI, como un Label
        } else {
            System.out.println("La consulta no devolvió resultados.");
        }
    }
    
    
}
