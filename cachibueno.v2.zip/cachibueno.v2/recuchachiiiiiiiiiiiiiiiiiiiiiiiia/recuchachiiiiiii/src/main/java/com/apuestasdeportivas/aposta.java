package com.apuestasdeportivas;

public class aposta {
    
    private Integer usuari_id;
    private Integer quota_id;
    private Float importe;
    private String data;
    
    public aposta(Integer usuari_id, Integer quota_id, Float importe, String data) {
        this.usuari_id = usuari_id;
        this.quota_id = quota_id;
        this.importe = importe;
        this.data = data;
    }

    public Integer getUsuari_id() {
        return usuari_id;
    }
    public void setUsuari_id(Integer usuari_id) {
        this.usuari_id = usuari_id;
    }
    public Integer getQuota_id() {
        return quota_id;
    }
    public void setQuota_id(Integer quota_id) {
        this.quota_id = quota_id;
    }
    public Float getImporte() {
        return importe;
    }
    public void setImporte(Float importe) {
        this.importe = importe;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }


    public void afegirAposta(Integer usuari_id, Integer quota_id, Float importe, String data) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "INSERT INTO aposta(usuari_id, quota_id, import, data) VALUES (" + 
                     usuari_id + ", " + quota_id + ", " + importe + ", '" + data + "')";
    
        db.update(sql);
    }

    
    public void editarAposta(int id, Integer usuari_id, Integer quota_id, Float importe, String data) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "UPDATE aposta SET " +
                     "usuari_id = " + usuari_id + ", " +
                     "quota_id = " + quota_id + ", " +
                     "import = " + importe + ", " +
                     "data = '" + data + "' " +
                     "WHERE id = " + id;
    
        db.update(sql);
    }
    

    public void eliminarAposta(int id) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "DELETE FROM aposta WHERE id = " + id;
    
        db.update(sql);
    }
    

    
}
