package com.apuestasdeportivas;

import com.utils.*;

import java.io.IOException;
import java.lang.ModuleLayer.Controller;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.function.Consumer;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class Controllercliente implements Initializable {
    private String userActivo;
    @FXML
    private Label user;
    @FXML
    private Button loginbutton;
    @FXML
    private ChoiceBox<String> choiceBox = new ChoiceBox<>();

    @FXML
    private TableView<HashMap<String, Object>> table;

    @FXML
    private Label label;


    


    @FXML
    private void abrirlogin(ActionEvent event) {
        try {
            userActivo = Sessio.getInstance().getUsername();
            editarUser crtl = (editarUser) UtilsViews.getController("ViewEditarPerfil");
    


                crtl.setUser(userActivo);
                crtl.carregarView(userActivo);         }
                catch (Exception e){
                    System.err.println("Error");
                }
    }
    
    // Called when the FXML file is loaded
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        mostraDetalls();
        // Configura el comportamiento del ChoiceBox cuando se selecciona un elemento
        choiceBox.setOnAction((event) -> {
            String selectedTable = choiceBox.getSelectionModel().getSelectedItem();
            // La selección puede ser 'null' cuando se reconstruye el 'choiceBox'
    
            if (selectedTable != null) {
                setTable(selectedTable);  // Actualiza la tabla seleccionada
            }
        });
    }
    
    /**
     * Llista les taules de la base de dades al 'choiceBox'
     * @param selectedTable taula que s'ha d'escollir (si existeix), o "" per la primera taula
     * @param selectedRow fila que s'ha de marcar (si existeix), o -1 si no se'n selecciona cap
     */
    public void loadTables(String selectedTable, int selectedRow) {
                String username = Sessio.getInstance().getUsername();
                System.out.println("Usuario desde sessio: " + username); 
            
        
                user.setText(username);  
        AppData db = AppData.getInstance();
        String sql = "SELECT name FROM sqlite_master WHERE type='table' AND name <> 'sqlite_sequence'";
        ArrayList<HashMap<String, Object>> rows = db.query(sql);
        System.out.println(rows);
        System.out.println("hola");
        
        // Posar els noms de les taules a 'tableNames'
        ArrayList<String> tableNames = new ArrayList<>();
        for (HashMap<String, Object> row : rows) {
            tableNames.add((String) row.get("name"));
        }

        // Posar els noms de les taules a la 'choiceBox'
        choiceBox.getItems().clear();
        choiceBox.getItems().addAll(tableNames);

        if (selectedTable.equalsIgnoreCase("") == false && tableNames.indexOf(selectedTable) != -1) {
            // Escollir la taula 'selectedTable'
            choiceBox.getSelectionModel().select(selectedTable);
            setTable(selectedTable);

            // Escollir la fila 'selectedRow'
            if (selectedRow >= 0 && selectedRow < table.getItems().size()) {
                table.getSelectionModel().select(selectedRow);
            }
        } else {
            // Escollir la primera taula
            choiceBox.getSelectionModel().selectFirst();
            setTable(tableNames.get(0));
        }
    }
        
    /**
     * Mostra una taula a la TableView 'table'
     * @param tableName nom de la taula a mostrar
     */
    @FXML
    private void setTable(String tableName) {

        // Vigilar que hi ha un 'tableName'
        if (tableName == null || tableName.trim().isEmpty()) {
            System.out.println("La taula seleccionada és null o buida.");
            return;
        }

        // Obtenir els continguts de la taula
        AppData db = AppData.getInstance();
        String sql = "";
        switch (tableName) {
            case "usuari":
                sql = "SELECT dni, nom || ' ' || cognoms AS nom_complet FROM usuari";
                break;
            case "esports":
                sql = "SELECT id, nom  FROM esports";
                break;
            case "partit":
                sql = "SELECT id, local, visitant, data, esport_id  FROM partit";
                break;
            case "equip":
                sql = "SELECT id, nom  FROM equip";
                break;
                case "quotes":
                sql = "SELECT * FROM quotes";
                break;
            case "aposta":
                sql = "SELECT id, usuari_id, quota_id, import, data FROM aposta";
                break;
            default:
                return; 
        }
        

        ArrayList<HashMap<String, Object>> rows = db.query(sql);

        // Esborrar les columnes i files actuals de la taula
        table.getColumns().clear();
        table.getItems().clear();

        if (!rows.isEmpty()) {

            // Determinar els noms de les columnes
            HashMap<String, Object> firstRow = rows.get(0);
            for (String key : firstRow.keySet()) {
                TableColumn<HashMap<String, Object>, Object> column = new TableColumn<>(key);
                column.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().get(key)));
                table.getColumns().add(column);
            }

            // Ajustar l'amplada de cada columna de manera equitativa
            table.getColumns().forEach(column ->
                column.prefWidthProperty().bind(table.widthProperty().divide(table.getColumns().size()))
            );
        }

        // Assignar les dades a la taula
        ObservableList<HashMap<String, Object>> data = FXCollections.observableArrayList(rows);
        table.setItems(data);

        // Afegir listener per detectar la selecció d'una fila
        table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            setLabelInfo(newSelection);
        });

        // Fer la taula editable
        makeTableEditable(table, row -> {
            String selectedTable = choiceBox.getSelectionModel().getSelectedItem();

            // Definir el nom de la clau primària, segons la taula
            String keyName = "id";
            boolean modified = setModifiedRow(selectedTable, keyName, row);
            if (modified) {
                setLabelInfo(row);
            }
        });
    }
    
    /**
     * Carrega de nou les dades de la base de dades
     * si hi ha una taula o fila sel·leccionades, intenta mantenir-les
     * @param event
     */
    @FXML
    public void reload(ActionEvent event) {
        String selectedTable = choiceBox.getSelectionModel().getSelectedItem();
        int selectedRow = table.getSelectionModel().getSelectedIndex();

        loadTables(selectedTable, selectedRow);
    }

    /**
     * Mostra la informació de la fila sel·lecionada al labe inferior
     * Si no hi ha cap fila escollida mostra "Cap fila escollida"
     * @param rowData
     */
    private void setLabelInfo(HashMap<String, Object> rowData) {
        if (rowData == null) {
            label.setText("Cap fila escollida");
        } else {
            StringBuilder info = new StringBuilder();
            rowData.forEach((key, value) -> info.append(key).append(": ").append(value).append("  "));
            label.setText(info.toString());
        }
    }

    /** 
     * Actualitza la base de dades quan es modifica una fila
     * @param tableName nom de la taula
     * @param rowData dades de la fila a actualitzar
     * @return true si s'ha fet el canvi
     */ 
    private boolean setModifiedRow(String tableName, String keyName, HashMap<String, Object> rowData) {

        if (rowData == null || tableName == null) return false;

        Object idValue = rowData.get(keyName);
        if (!(idValue instanceof Integer)) {
            System.out.println("No es pot actualitzar: no hi ha clau primària '" + keyName + "'");
            return false;
        }
    
        StringBuilder setClause = new StringBuilder();
        for (String key : rowData.keySet()) {
            if (key.equals(keyName)) continue;
    
            Object value = rowData.get(key);
            if (setClause.length() > 0) setClause.append(", ");
    
            // Adaptar la query a "sqlite"
            if (value == null) {
                setClause.append(String.format("%s = NULL", key));
            } else if (value instanceof Number) {
                setClause.append(String.format("%s = %s", key, value));
            } else {
                String escaped = value.toString().replace("'", "''");
                setClause.append(String.format("%s = '%s'", key, escaped));
            }
        }
    
        String sql = String.format("UPDATE %s SET %s WHERE %s = %s", tableName, setClause, keyName, idValue);
        AppData.getInstance().update(sql);
        System.out.println("Actualitzat: " + sql);
    
        return true;
    }




 
    /** 
     * Transforma una taula en editable
     * @param table, taula que ha de ser editable
     * @param onEdit, mètode a executar quan s'ha editat una fila
     */ 
    public static void makeTableEditable(TableView<HashMap<String, Object>> table, Consumer<HashMap<String, Object>> onEdit) {
        table.setEditable(true);

        if (table.getItems().isEmpty()) return;

        for (TableColumn<HashMap<String, Object>, ?> tc : table.getColumns()) {
            @SuppressWarnings("unchecked")
            TableColumn<HashMap<String, Object>, Object> col = (TableColumn<HashMap<String, Object>, Object>) tc;
            String key = col.getText();
            Object sampleValue = table.getItems().get(0).get(key);

            StringConverter<Object> converter;

            if (sampleValue instanceof Integer) {
                converter = new StringConverter<>() {
                    public String toString(Object o) { return o == null ? "" : o.toString(); }
                    public Object fromString(String s) {
                        try { return Integer.parseInt(s); } catch (Exception e) { return 0; }
                    }
                };
            } else if (sampleValue instanceof Double) {
                converter = new StringConverter<>() {
                    public String toString(Object o) { return o == null ? "" : o.toString(); }
                    public Object fromString(String s) {
                        try { return Double.parseDouble(s); } catch (Exception e) { return 0.0; }
                    }
                };
            } else {
                converter = new StringConverter<>() {
                    public String toString(Object o) { return o == null ? "" : o.toString(); }
                    public Object fromString(String s) { return s; }
                };
            }

            col.setCellFactory(TextFieldTableCell.forTableColumn(converter));
            col.setOnEditCommit(e -> {
                e.getRowValue().put(key, e.getNewValue());
                onEdit.accept(e.getRowValue());
            });
        }
    }

    @FXML
    public void crear() {

        //TODO
        /*
         * Hacer una vista de creacion de personas(tienen 5 campos) + luego hacer una para registre-vendes para asi poder crear cosas.
         * 
         * 
         * 
         * 
         * 
         * 
         */
        try {
            String tabla = choiceBox.getValue();
            System.out.println("tabla seleccionada" + tabla);
            switch (tabla) {
                case "equip":
                    UtilsViews.setViewAnimating("crearEquip");
                    
                    break;
                case "partit":
                    UtilsViews.setViewAnimating("ViewCrearPartit");
                    
                    break;
                case "autor":
                    UtilsViews.setViewAnimating("ViewCrearAutors");
                     
                    break;
                default:
                    break;
            }

        } catch (Exception e4) {
            System.out.println("❌ Se produjo un error inesperado: " + e4.getMessage());
            e4.printStackTrace();
        }
    }
    public void mostraDetalls() {
        table.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent e) {
                HashMap<String, Object> selectedRow = table.getSelectionModel().getSelectedItem();
                if (selectedRow == null) return;  // Si no se seleccionó ninguna fila, salir.
    
                String selectedTable = choiceBox.getSelectionModel().getSelectedItem();
                if (selectedTable == null) {
                    System.out.println("❌ No se seleccionó ninguna tabla en el ChoiceBox");
                    return;
                }
    
                try {
                    switch (selectedTable) {
                        case "partit": {
                            Object value = selectedRow.get("id");
                            if (value != null) {
                                int id = Integer.parseInt(value.toString());
    
                                ControllerPartits crtl = (ControllerPartits) UtilsViews.getController("ViewPartit");
                                UtilsViews.setView("ViewPartit");
                                crtl.carregarView(id);
                            } else {
                                System.out.println("❌ No se encontró el 'id' en la fila seleccionada");
                            }
                            break;
                        }
                        case "equip": {
        
                            break;
                        


                            // Similar a "partit", maneja el caso de autor aquí.
                        }
                        case "usuaris": {
                            // Similar a "partit", maneja el caso de usuaris aquí.
                            break;
                        }
                        default:
                            System.out.println("❌ Tabla no válida: " + selectedTable);
                            break;
                    }
                } catch (Exception ex) {
                    System.out.println("❌ Error al cargar detalles: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
    }
    





}