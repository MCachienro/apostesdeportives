package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;
import com.utils.UtilsViews;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;

public class crearEquipController {

    private String imagePath;

    @FXML private Button buttonLoadImage;
    @FXML private Button buttonAdd;
    @FXML private Button backButton;
    @FXML private TextField nom;
    @FXML private ChoiceBox<String> deporteChoiceBox;
    @FXML private ImageView img;

    public void initialize() {
        carregarDeportes();
    }

    private void carregarDeportes() {
        AppData db = AppData.getInstance();
        String sql = "SELECT nom FROM esports";
        ArrayList<HashMap<String, Object>> result = db.query(sql);

        ArrayList<String> deportes = new ArrayList<>();
        for (HashMap<String, Object> row : result) {
            deportes.add((String) row.get("nom"));
        }

        deporteChoiceBox.getItems().clear();
        deporteChoiceBox.getItems().addAll(deportes);
    }

    @FXML
    private void Enrere(ActionEvent event) throws Exception {
        UtilsViews.setViewAnimating("ViewTabla");
    }

    @FXML
    private void CrearEquipNou() {
        equip nouEquip = validarDades();
        if (nouEquip != null) {
            equipDao dao = new equipDao();
            dao.afegirEquip(nouEquip);
            mostrarAlertaInfo("Equip afegit correctament.");
        }
    }

    private equip validarDades() {
        String nomEquip = nom.getText();
        String esportSeleccionat = deporteChoiceBox.getValue();

        if (nomEquip == null || nomEquip.isEmpty()) {
            mostrarAlerta("El nom de l'equip no pot estar buit.");
            return null;
        }

        if (esportSeleccionat == null || esportSeleccionat.isEmpty()) {
            mostrarAlerta("Has de seleccionar un esport.");
            return null;
        }

        if (imagePath == null || imagePath.isEmpty()) {
            mostrarAlerta("Has de seleccionar una imatge.");
            return null;
        }

        return new equip(nomEquip, imagePath, esportSeleccionat);
    }

    @FXML
    private void actionLoadImage() {
        Stage stage = (Stage) buttonLoadImage.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imatges", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile != null) {
            try {
                File targetDir = new File(System.getProperty("user.dir") + "/src/main/resources/assets/images");
                if (!targetDir.exists()) targetDir.mkdirs();

                String fileName = selectedFile.getName();
                Path targetPath = Path.of(targetDir.getAbsolutePath(), fileName);
                Files.copy(selectedFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);

                Image image = new Image(targetPath.toUri().toString());
                img.setImage(image);
                this.imagePath = "assets/images/" + fileName;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void mostrarAlerta(String missatge) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(missatge);
        alert.show();
    }

    private void mostrarAlertaInfo(String missatge) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informació");
        alert.setHeaderText(null);
        alert.setContentText(missatge);
        alert.show();
    }
}
