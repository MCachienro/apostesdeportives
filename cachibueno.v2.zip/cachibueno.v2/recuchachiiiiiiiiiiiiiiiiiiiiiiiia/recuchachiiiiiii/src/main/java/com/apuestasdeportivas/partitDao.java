package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;

public class partitDao {

    // Agregar un partido
    public void afegirPartit(partit partit) {
        AppData db = AppData.getInstance();

        // Usar las columnas correctas en la base de datos (id_local, id_visitant)
        String sql = "INSERT INTO partit (id_local, id_visitant, data, esport_id) VALUES ("
                + partit.getLocal_id() + ", "
                + partit.getVisitant_id() + ", '"
                + partit.getData().replace("'", "''") + "', "
                + partit.getEsport_id() + ")";

        try {
            db.update(sql);
            System.out.println("partit afegit correctament.");
        } catch (Exception e) {
            System.out.println("Error en afegir el partit: " + e.getMessage());
        }
    }

    // Actualizar partido por ID
    public void update(int id, partit partit) {
        AppData db = AppData.getInstance();

        // Usar las columnas correctas en la base de datos (id_local, id_visitant)
        String sql = "UPDATE partit SET "
                + "id_local = " + partit.getLocal_id() + ", "
                + "id_visitant = " + partit.getVisitant_id() + ", "
                + "data = '" + partit.getData().replace("'", "''") + "', "
                + "esport_id = " + partit.getEsport_id() + " "
                + "WHERE id = " + id;

        try {
            db.update(sql);
            System.out.println("partit actualitzat correctament.");
        } catch (Exception e) {
            System.out.println("Error en actualitzar el partit: " + e.getMessage());
        }
    }

    // Eliminar un partido por ID
    public void eliminarPartit(int id) {
        AppData db = AppData.getInstance();

        // Borrar el partido por su ID
        String sql = "DELETE FROM partit WHERE id = " + id;

        try {
            db.update(sql);
            System.out.println("partit eliminat correctament.");
        } catch (Exception e) {
            System.out.println("Error en eliminar el partit: " + e.getMessage());
        }
    }

    // Obtener todos los partidos
    public ArrayList<partit> obtenerTodosPartits() {
        AppData db = AppData.getInstance();
        String sql = "SELECT * FROM partit";
        ArrayList<HashMap<String, Object>> result = db.query(sql);

        ArrayList<partit> partits = new ArrayList<>();

        for (HashMap<String, Object> row : result) {
            int local = ((Number) row.get("id_local")).intValue();  // Correcto: usar id_local
            int visitant = ((Number) row.get("id_visitant")).intValue();  // Correcto: usar id_visitant
            String data = (String) row.get("data");
            int esport_id = ((Number) row.get("esport_id")).intValue();

            partits.add(new partit(local, visitant, data, esport_id));
        }

        return partits;
    }
}
