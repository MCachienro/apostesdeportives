package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;

import com.utils.UtilsViews;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;


public class login {

    @FXML private TextField nomusuari;
    @FXML private PasswordField contrasenyausuari;
    @FXML private Button loginButton;
    @FXML private AnchorPane panel;


    @FXML
    public void logearse() {
        String usuari = nomusuari.getText().trim();
        String contrasenya = contrasenyausuari.getText();

        if (usuari.isEmpty() || contrasenya.isEmpty()) {
            System.out.println("El camp d'usuari o contrasenya està buit.");
            return;
        }

        AppData db = AppData.getInstance();
        String sqlString = "SELECT contrasenya FROM usuari WHERE usuaris = '" + usuari + "'";
        ArrayList<HashMap<String, Object>> resultats = db.query(sqlString);

        if (resultats.isEmpty()) {
            System.out.println("Usuari no trobat.");
            return;
        }

        String contrasenyaDB = (String) resultats.get(0).get("contrasenya");

        if (contrasenya.equals(contrasenyaDB)) {
            Sessio.getInstance().setUsername(usuari);
            System.out.println("Usuari loguejat: " +  Sessio.getInstance().getUsername());
            if(Sessio.getInstance().getUsername().equals("a")){
                UtilsViews.setViewAnimating("ViewTabla");
        

            }else{
                UtilsViews.setViewAnimating("ViewCliente");

            }
        } else {
            System.out.println("Contrasenya incorrecta.");
        }
    }


    @FXML
    public void initialize() {
        Image fondo = new Image("/assets/images/cas.png");
        BackgroundImage fondoderecha = new BackgroundImage(
            fondo,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            new BackgroundSize(100, 100, true, true, true, false)
        );
        panel.setBackground(new Background(fondoderecha));
    }
}
