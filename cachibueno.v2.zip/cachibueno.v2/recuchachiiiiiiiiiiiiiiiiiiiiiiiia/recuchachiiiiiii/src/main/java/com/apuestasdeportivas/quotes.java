package com.apuestasdeportivas;

public class quotes {
    private Integer partit_id;
    private String descripcio;
    private Float quota;
    private Integer equip_id;

    
    public quotes(Integer partit_id, String descripcio, Float quota, Integer equip_id) {
        this.partit_id = partit_id;
        this.descripcio = descripcio;
        this.quota = quota;
        this.equip_id = equip_id;

    }

    public Integer getPartit_id() {
        return partit_id;
    }
    public void setPartit_id(Integer partit_id) {
        this.partit_id = partit_id;
    }
    public String getDescripcio() {
        return descripcio;
    }
    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }
    public Float getQuota() {
        return quota;
    }
    public void setQuota(Float quota) {
        this.quota = quota;
    }
    public Integer getequip_id(){
        return equip_id;
    }
    public void setequip_id(Integer equip_id){
        this.equip_id = equip_id;
    }


    public void afegirQuota(Integer partit_id, String descripcio, Float quota_local, Float quota_visitant) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "INSERT INTO quotes(partit_id, descripcio, quota_local, quota_visitant) VALUES (" + 
                     partit_id + ", '" + descripcio + "', " + quota_local + ", " + quota_visitant + ")";
    
        db.update(sql);
    }
    
    public void editarQuota(int id, Integer partit_id, String descripcio, Float quota_local, Float quota_visitant) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "UPDATE quotes SET " +
                     "partit_id = " + partit_id + ", " +
                     "descripcio = '" + descripcio + "', " +
                     "quota_local = " + quota_local + ", " +
                     "quota_visitant = " + quota_visitant + " " +
                     "WHERE id = " + id;
    
        db.update(sql);
    }
    
    public void eliminarQuota(int id) {
        AppData db = AppData.getInstance();
    
        // Construcción de la consulta SQL
        String sql = "DELETE FROM quotes WHERE id = " + id;
    
        db.update(sql);
    }
    
    

    
}
