package com.apuestasdeportivas;

public class esport {
    private String nom;


    public String getNom() {
        return this.nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}



