package com.apuestasdeportivas;

public class equip {
    private String nom;
    private String imatge;
    private String deporte; // nombre del deporte desde el TextField


    
    public equip(String nom, String imatge, String deporte) {
        this.nom = nom;
        this.imatge = imatge;
        this.deporte = deporte;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getImatge() {
        return imatge;
    }

    public void setImatge(String imatge) {
        this.imatge = imatge;
    }

    public String getDeporte() {
        return deporte;
    }
    
    public void setDeporte(String deporte) {
        this.deporte = deporte;
    }
}
