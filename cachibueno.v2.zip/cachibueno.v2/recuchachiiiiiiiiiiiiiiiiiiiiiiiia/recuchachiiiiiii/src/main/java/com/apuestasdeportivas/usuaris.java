package com.apuestasdeportivas;

public class usuaris {
    private String nom;
    private String cognom;
    private String dni;
    private String usuari;
    private String contrasenya;
    private String email;
    private double saldo;

    public usuaris(String nom, String cognom, String dni, String usuari, String contrasenya, String email, double saldo) {
        this.nom = nom;
        this.cognom = cognom;
        this.dni = dni;
        this.usuari = usuari;
        this.contrasenya = contrasenya;
        this.email = email;
        this.saldo = saldo;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCognom() {
        return cognom;
    }

    public void setCognom(String cognom) {
        this.cognom = cognom;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getUsuari() {
        return usuari;
    }

    public void setUsuari(String usuari) {
        this.usuari = usuari;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void afegirusuari(String nom, String cognom, String dni, String usuari, String contrasenya, String email, double saldo) {
        AppData db = AppData.getInstance();

        String sql = "INSERT INTO usuari(nom, cognoms, dni, usuari, contrasenya, email, saldo) VALUES (" +
                     "'" + nom + "', " +
                     "'" + cognom + "', " +
                     "'" + dni + "', " +
                     "'" + usuari + "', " +
                     "'" + contrasenya + "', " +
                     "'" + email + "', " +
                     saldo + ")";

        db.update(sql);
    }

    public void editarUsuari(String dni, String nom, String cognom, String usuari, String contrasenya, String email, double saldo) {
        AppData db = AppData.getInstance();

        String sql = "UPDATE usuari SET " +
                     "nom = '" + nom + "', " +
                     "cognoms = '" + cognom + "', " +
                     "usuari = '" + usuari + "', " +
                     "contrasenya = '" + contrasenya + "', " +
                     "email = '" + email + "', " +
                     "saldo = " + saldo + " " +
                     "WHERE dni = '" + dni + "'";

        db.update(sql);
    }

    public void eliminarUsuari(String dni) {
        AppData db = AppData.getInstance();

        String sql = "DELETE FROM usuari WHERE dni = '" + dni + "'";

        db.update(sql);
    }
}
