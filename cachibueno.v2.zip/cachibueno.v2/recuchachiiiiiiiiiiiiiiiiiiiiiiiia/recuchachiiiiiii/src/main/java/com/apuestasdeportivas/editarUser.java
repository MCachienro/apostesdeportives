package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

import com.utils.UtilsViews;

public class editarUser implements Initializable {

    private String user;

    @FXML private Button editar;
    @FXML private Button backButton;
    @FXML private TextField saldo;
    @FXML private TextField nom;
    @FXML private TextField cognom;
    @FXML private TextField correu;
    @FXML private TextField usuari1;
    @FXML private PasswordField password;
    @FXML private PasswordField ConfirmarPassword;
    @FXML private TextField dni;


    public void setUser(String user) {
        this.user = user;
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        user = Sessio.getInstance().getUsername(); // ✅ Guardamos en la variable global
        System.out.println("Usuario actual desde Sessio: " + user);
        cargarManga(user);
    }

    public void carregarView(String id) throws Exception {
        cargarManga(user);
        UtilsViews.setView("ViewEditarPerfil");
    }

    public ArrayList<HashMap<String, Object>> ObtenirManga(String sql) {
        AppData db = AppData.getInstance();
        ArrayList<HashMap<String, Object>> result = db.query(sql);
    
        System.out.println("Resultado de la consulta: " + result); 
        return result;
    }
    

    @FXML
    private void actualitzarUsuari() {
        String nomText = nom.getText();
        String cognomText = cognom.getText();
        String mailText = correu.getText();
        String usernameText = usuari1.getText();
        String passwdText = password.getText();
        String confirmarPasswdText = ConfirmarPassword.getText();
        String dniText = dni.getText();
        Double saldoText = Double.parseDouble(saldo.getText());
        int id = ObtenirId();
        usuaris usuariNou = new usuaris(nomText, cognomText, dniText, usernameText, passwdText, mailText, saldoText);
        UsuariDao usuariDao = new UsuariDao();
        usuariDao.update(id, usuariNou);
    }

    private void cargarManga(String user) {
        if (user == null || user.isEmpty()) {
            System.out.println("El usuario es null o vacío. No se puede cargar.");
            return;
        }
    
        String sql = "SELECT * FROM usuari WHERE usuaris = '" + user + "'"; 
        System.out.println("Consulta SQL: " + sql);
    
        ArrayList<HashMap<String, Object>> mangaData = ObtenirManga(sql);
    
        if (!mangaData.isEmpty()) {
            PoblarCamps(mangaData); 
        } else {
            System.out.println("No se encontraron datos del usuario.");
        }
    }
    
    public void PoblarCamps(ArrayList<HashMap<String, Object>> query) {
        if (query != null && !query.isEmpty()) {
            HashMap<String, Object> map = query.get(0); 
            System.out.println("HashMap recibido: " + map);
    
            Object nomValue = map.get("nom");
            Object cognomValue = map.get("cognoms"); 
            Object emailValue = map.get("email"); 
            Object dniValue = map.get("dni"); 
            Object usuariValue = map.get("usuaris");
            Object contrasenyaValue = map.get("contrasenya");
            Object comprobarContrasenya = map.get("contrasenya");
            Object saldoValue = map.get("saldo");

            if (nomValue != null) nom.setText(nomValue.toString());
            if (cognomValue != null) cognom.setText(cognomValue.toString());
            if (emailValue != null) correu.setText(emailValue.toString());
            if (dniValue != null) dni.setText(dniValue.toString());
            if (usuariValue != null) usuari1.setText(usuariValue.toString());
            if (contrasenyaValue != null) password.setText(contrasenyaValue.toString());
            if (comprobarContrasenya != null) ConfirmarPassword.setText(comprobarContrasenya.toString());
            if (saldoValue != null) saldo.setText(saldoValue.toString());
        } else {
            System.out.println("No hay datos para poblar.");
        }
    }

    public int ObtenirId() {
        AppData ap = AppData.getInstance();

        String sql = "SELECT id FROM usuari WHERE usuaris = '" + user + "'";
        ArrayList<HashMap<String, Object>> resultado = ap.query(sql);
        Object idObj = resultado.get(0).get("id");
        return (Integer) idObj;

    }
    public void Enrere(){
        UtilsViews.setView("ViewTabla");
    }
}
