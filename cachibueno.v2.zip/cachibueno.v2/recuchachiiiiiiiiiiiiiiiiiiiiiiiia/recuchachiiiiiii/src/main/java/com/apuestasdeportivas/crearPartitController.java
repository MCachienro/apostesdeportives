package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;
import com.utils.UtilsViews;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;

public class crearPartitController {

    private String imagePath;

    @FXML private Button buttonLoadImage;
    @FXML private Button buttonAdd;
    @FXML private Button backButton;
    @FXML private TextField nom;
    @FXML private ChoiceBox<String> deporteChoiceBox, localChoiceBox, VisitanteChoiceBox;
    @FXML private ImageView img;
    @FXML private DatePicker datePicker;
    @FXML private TextField quotalocal;
    @FXML private TextField quotavisitante;

    public void initialize() {
        cargarDeportes();

        // Añadir listener para cargar equipos cuando se seleccione un deporte
        deporteChoiceBox.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            cargarEquips(newValue); // Llama a cargar equipos con el nuevo deporte seleccionado
        });
    }

    private void cargarDeportes() {
        AppData db = AppData.getInstance();
        String sql = "SELECT nom FROM esports";
        ArrayList<HashMap<String, Object>> result = db.query(sql);

        ArrayList<String> deportes = new ArrayList<>();
        for (HashMap<String, Object> row : result) {
            deportes.add((String) row.get("nom"));
        }

        deporteChoiceBox.getItems().clear();
        deporteChoiceBox.getItems().addAll(deportes);
    }

    private void cargarEquips(String esport) {
        AppData db = AppData.getInstance();

        // Primera consulta: obtener el id del deporte
        String sql = "SELECT id FROM esports WHERE nom = '" + esport + "'";
        ArrayList<HashMap<String, Object>> result = db.query(sql);

        if (result.isEmpty()) {
            return; // Si no hay resultados, no hacer nada
        }

        Integer esportId = (Integer) result.get(0).get("id");

        // Segunda consulta: obtener los nombres de los equipos
        String sql2 = "SELECT nom FROM equip WHERE esports_id = " + esportId;
        ArrayList<HashMap<String, Object>> equiposResult = db.query(sql2);

        ArrayList<String> equipos = new ArrayList<>();
        for (HashMap<String, Object> row : equiposResult) {
            equipos.add((String) row.get("nom"));
        }

        localChoiceBox.getItems().clear();
        VisitanteChoiceBox.getItems().clear();
        localChoiceBox.getItems().addAll(equipos);
        VisitanteChoiceBox.getItems().addAll(equipos);
    }

    @FXML
    private void Enrere(ActionEvent event) throws Exception {
        UtilsViews.setViewAnimating("ViewTabla");
    }

    @FXML
    private void CrearPartit() {
        partit nouPartit = validarDades();
        if (nouPartit != null) {
            partitDao dao = new partitDao();
            dao.afegirPartit(nouPartit);
            guardarQuotaLocal(nouPartit, localChoiceBox.getValue(), quotalocal.getText());
            guardarQuotaLocal(nouPartit, VisitanteChoiceBox.getValue(), quotavisitante.getText());
            mostrarAlertaInfo("partit afegit correctament.");
        }
    }
    

    private partit validarDades() {
        String localEquip = localChoiceBox.getValue();
        String visitanteEquip = VisitanteChoiceBox.getValue();
        String dataPartit = datePicker.getValue() != null ? datePicker.getValue().toString() : "";
    
        if (localEquip == null || localEquip.isEmpty()) {
            mostrarAlerta("Has de seleccionar un equip local.");
            return null;
        }
    
        if (visitanteEquip == null || visitanteEquip.isEmpty()) {
            mostrarAlerta("Has de seleccionar un equip visitant.");
            return null;
        }
    
        if (dataPartit.isEmpty()) {
            mostrarAlerta("Has de seleccionar una data.");
            return null;
        }
    
        if (localEquip.equals(visitanteEquip)) {
            mostrarAlerta("Els equips local i visitant no poden ser iguals.");
            return null;
        }
    
        int localId = obtenerEquipId(localEquip);
        int visitantId = obtenerEquipId(visitanteEquip);
        int esportId = obtenerEsportId();
    
        if (localId == -1 || visitantId == -1 || esportId == -1) {
            mostrarAlerta("No s'han pogut obtenir els identificadors dels equips o esport.");
            return null;
        }
    
        return new partit(localId, visitantId, dataPartit, esportId);
    }
    

    private int obtenerEsportId() {
        // Obtener el ID del deporte seleccionado
        String esportSeleccionado = deporteChoiceBox.getValue();
        AppData db = AppData.getInstance();
        String sql = "SELECT id FROM esports WHERE nom = '" + esportSeleccionado + "'";
        ArrayList<HashMap<String, Object>> result = db.query(sql);

        if (result.isEmpty()) return -1;

        return (Integer) result.get(0).get("id");
    }
    private int obtenerEquipId(String nomEquip) {
        AppData db = AppData.getInstance();
        String sql = "SELECT id FROM equip WHERE nom = '" + nomEquip.replace("'", "''") + "'";
        ArrayList<HashMap<String, Object>> result = db.query(sql);
    
        if (result == null || result.isEmpty()) return -1;
    
        return (Integer) result.get(0).get("id");
    }
    

    @FXML
    private void actionLoadImage() {
        Stage stage = (Stage) buttonLoadImage.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imatges", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile != null) {
            try {
                File targetDir = new File(System.getProperty("user.dir") + "/src/main/resources/assets/images");
                if (!targetDir.exists()) targetDir.mkdirs();

                String fileName = selectedFile.getName();
                Path targetPath = Path.of(targetDir.getAbsolutePath(), fileName);
                Files.copy(selectedFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);

                Image image = new Image(targetPath.toUri().toString());
                img.setImage(image);
                this.imagePath = "assets/images/" + fileName;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void mostrarAlerta(String missatge) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(missatge);
        alert.show();
    }

    private void mostrarAlertaInfo(String missatge) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informació");
        alert.setHeaderText(null);
        alert.setContentText(missatge);
        alert.show();
    }

    
    

    private void guardarQuotaLocal(partit partit, String nomEquipLocal, String quotavalor) {
        try {
            int equipId = obtenerEquipId(nomEquipLocal);
            float quota = Float.parseFloat(quotavalor);
            
            quotesDao dao = new quotesDao();
            quotes novaQuota = new quotes(partit.getid(),"Guanya "+ nomEquipLocal, quota, equipId); // Ajusta si tu constructor es diferente
            dao.afegirQuota(novaQuota); // Asegúrate que este método exista en quotesDao
    
        } catch (NumberFormatException e) {
            mostrarAlerta("La quota local no és un número vàlid.");
        } catch (Exception e) {
            mostrarAlerta("Error al guardar la quota local: " + e.getMessage());
        }
    }
    
}
