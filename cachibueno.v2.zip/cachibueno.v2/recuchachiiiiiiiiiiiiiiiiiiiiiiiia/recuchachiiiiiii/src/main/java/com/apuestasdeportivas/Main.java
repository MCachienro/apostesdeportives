package com.apuestasdeportivas;

import com.utils.*;

import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

// Fes anar l'exemple amb:
// ./run.sh com.exemple1602.Main

public class Main extends Application {

    final int WINDOW_WIDTH = 1000;
    final int WINDOW_HEIGHT = 600;
    final int MIN_WIDTH = 600;
    final int MIN_HEIGHT = 400;
    public static void main(String[] args) {
        db.crearusuaris();
        db.insertarUsers();
        db.crearusuaris();
        db.crearesports();
        db.crearequip();
        db.crearpartits();
        db.crearquotes();
        db.crearaposta();
        db.insertarUsers();
        db.insertarDatosEjemplo();

        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        // Carrega la vista inicial des del fitxer FXML
        UtilsViews.parentContainer.setStyle("-fx-font: 14 arial;");
        UtilsViews.addView(getClass(), "ViewLogin", "/assets/loginusuario.fxml");
        UtilsViews.addView(getClass(), "ViewLoginUsuari", "/assets/login.fxml");
        UtilsViews.addView(getClass(), "ViewCrearUsuari", "/assets/nouusuari.fxml");
        UtilsViews.addView(getClass(), "ViewTabla", "/assets/vistatabla.fxml");
        UtilsViews.addView(getClass(), "ViewEditarPerfil", "/assets/editarUsuari.fxml");
        UtilsViews.addView(getClass(), "ViewPartit", "/assets/vistaPartidos.fxml");
        UtilsViews.addView(getClass(), "ViewCliente", "/assets/vistatacliente.fxml");
        UtilsViews.addView(getClass(), "ViewCrearEquip", "/assets/vistaCrearEquip.fxml");
        UtilsViews.addView(getClass(), "ViewCrearEsport", "/assets/crearEsport.fxml");
        UtilsViews.addView(getClass(), "ViewCrearPartit", "/assets/vistaCrearPartits.fxml");
        // Connectar amb la base de dades
        AppData db = AppData.getInstance();
        db.connect("./data/apuestas.sqlite");

        // Carregar la informació de taules a 'ControllerTabla'
        ControllerTabla crtl = (ControllerTabla) UtilsViews.getController("ViewTabla");

        
        crtl.loadTables("", -1);

        // Mostrar l'escena
        Scene scene = new Scene(UtilsViews.parentContainer);

        stage.setScene(scene);
        stage.setTitle("JavaFX App");
        stage.setMinWidth(MIN_WIDTH);
        stage.setWidth(WINDOW_WIDTH);
        stage.setMinHeight(MIN_HEIGHT);
        stage.setHeight(WINDOW_HEIGHT);
        stage.show();
        

        // Afegeix una icona només si no és un Mac
        if (!System.getProperty("os.name").contains("Mac")) {
            Image icon = new Image("file:icons/icon.png");
            stage.getIcons().add(icon);
        }
    }
    // Aquesta funció es crida quan es tanca l'aplicació
    @Override
    public void stop() throws Exception {
        AppData db = AppData.getInstance();
        db.close();
        super.stop();
    }
}
