package com.apuestasdeportivas;

import java.util.ArrayList;
import java.util.HashMap;

import com.utils.UtilsViews;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class editarcontroller {

    private String dniActual;

    @FXML
    private Button buttonUpdate;
    @FXML
    private Button backButton;

    @FXML
    private TextField nom;
    @FXML
    private TextField cognoms;
    @FXML
    private TextField usernom;
    @FXML
    private TextField contrasenya;
    @FXML
    private TextField email;

    public void setDni(String dni) {
        this.dniActual = dni;
        cargarUsuari();
    }

    @FXML
    private void Enrere(ActionEvent event) throws Exception {
        UtilsViews.setView("ViewMain");
    }

    @FXML
    private void actualizarUsuari() {
        String nomNou = nom.getText();
        String cognomNou = cognoms.getText();
        String usuariNou = usernom.getText();
        String passwd = contrasenya.getText();
        String mail = email.getText();

        usuaris usuari = new usuaris(nomNou, cognomNou, dniActual, usuariNou, passwd, mail, 0.0);
        UsuariDao usuariDao = new UsuariDao();
        usuariDao.update(Integer.parseInt(dniActual), usuari);

        System.out.println("Usuari actualitzat correctament.");
    }

    private void cargarUsuari() {
        String sql = "SELECT * FROM usuari WHERE dni = '" + dniActual + "'";
        ArrayList<HashMap<String, Object>> datos = ObtenirUsuari(sql);

        if (!datos.isEmpty()) {
            PoblarCamps(datos);
        }
    }

    public ArrayList<HashMap<String, Object>> ObtenirUsuari(String sql) {
        AppData db = AppData.getInstance();
        return db.query(sql);
    }

    public void PoblarCamps(ArrayList<HashMap<String, Object>> query) {
        if (query != null && !query.isEmpty()) {
            HashMap<String, Object> map = query.get(0);

            nom.setText(map.get("nom").toString());
            cognoms.setText(map.get("cognoms").toString());
            usernom.setText(map.get("usuari").toString());
            contrasenya.setText(map.get("contrasenya").toString());
            email.setText(map.get("email").toString());
        }
    }
}
