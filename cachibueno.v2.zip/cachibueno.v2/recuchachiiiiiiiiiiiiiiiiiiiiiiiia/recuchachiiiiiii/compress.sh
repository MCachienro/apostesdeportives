#!/bin/bash

zip -r recuchachi.zip . -x "*.DS_Store" "*/__MACOSX/*" "*.zip"  "*node_modules*" "*.build/*"